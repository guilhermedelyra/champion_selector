import sys
import urllib3
import requests
import json
from collections import defaultdict, OrderedDict
import re

print('oi')